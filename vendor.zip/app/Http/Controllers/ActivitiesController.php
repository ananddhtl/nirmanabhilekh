<?php

namespace App\Http\Controllers;
use App\Models\Activity;
use App\Exports\ActivtiesExport;
use App\Models\ActivityCatagory;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;


class ActivitiesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(){
    
    $activitiescatagories=ActivityCatagory::select('*')->get();



    return view('frontend.activities.add',compact('activitiescatagories'));
}
public function searchActivities($searchkey)
{
    $Activity = Activity::select('id', 'activities_title', )->where('activities_title', 'like', '' . $searchkey . '%')->get()->take(10);
    return json_encode($Activity);
}  
    public function getActivityData()
{
    $data = DB::table('activities',)
    ->join('activity_catagories', 'activities.activities_cat_ID', '=', 'activity_catagories.id')
    ->select('activities.*', 'activity_catagories.activity_catagories_name')
    ->where('activities.status','=',0)
    ->simplePaginate(10);
    return view('frontend.activities.list', compact('data'));
    

    
}  
    function postActivitiesData(Request $request){

        $request->validate([
        
        'activities_title'=>'required  | min:3',
        'activities_subtitle'=>'required  | min:3',
      
        ]);

        $activities = new Activity;
        $activities->id= $request->id;
        $activities->activities_title= $request->activities_title;
        $activities->activities_subtitle= $request->activities_subtitle;
        $activities->activities_cat_ID= $request->activities_cat_ID;
        $activities->status = 0;
        

        $activities->save();
        return redirect('/activities/list')->with('status',' Your data has been added successfully');
    }
    public function deleteActivities($id) 
    {
        Activity::where('id','=',$id)->update([
           'status' => 1,
        ]);
        return redirect('/activities/list')->with('message','Your data has been deleted successfully');
    }
    public function editActivities($id){

        $activitiescatagories=ActivityCatagory::select('*')->get();

   
        $data = Activity::where('id',$id)->first();
    
        return view('frontend.activities.edit',compact('data','activitiescatagories'));
    }
    public function updateActivities($id ,Request $request)
    {
        Activity::where('id','=' ,$request->id) ->update([
            'activities_title'=>$request->activities_title,
            'activities_subtitle'=>$request->activities_subtitle,
            'activities_cat_ID'=>$request->activities_cat_ID,
            'status' => 0,
            


        ]);
        return redirect('/activities/list')->with('messages', 'Your  data has been updated succesfully');
    }
    public function search(Request $request, )
    {   $get_name = $request->search_name;
        $data = DB::table('activities',)
        ->join('activity_catagories', 'activities.activities_cat_ID', '=', 'activity_catagories.id')
        ->select('activities.*', 'activity_catagories.activity_catagories_name')
        ->where('activities.status','=',0)
        ->where('activities_title','like','%'.$get_name.'%')
        ->simplePaginate(10);
        
         
        return view('frontend.activities.list',compact('data'));
  
    
    }
    public function export(){
        return  Excel::download(new ActivtiesExport, 'activity.xlsx');
    }

}
